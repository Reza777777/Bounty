<?php

return [
    'Account verification' => ' ',
    'To get your account verified, please fill in all the required fields and upload the document images.' => ' ',

    'Your account verification status' => ' ',
    'The system is reviewing your documents. This process usually takes between 3 to 5 minutes, but may take up to 24 hours.' => ' ',
    'The status of your account will change automatically once the review is completed. If you experience any difficulties, please contact our support. If the resulting status is successful, you will have the opportunity to purchase tokens.' => ' ',
    'If uploaded document is incorrect then you can upload it again at this page.' => ' ',

    'Select type of document' => ' ',
    'Please select the type above' => ' ',
    'Successfully added' => ' ',
    'Reset' => ' ',

    'Verify my account' => ' ',
    'Color and black & white are all accepted.' => ' ',
    'All your corners of the document need to be in the image, no tilt, no rotation.' => ' ',
    'The system rejects photos with traces of image editors like Photoshop.' => ' ',
    'No shadow, reflection, small photos, spam.' => ' ',
    'All images must be of good quality, so that all the inscriptions are readable.' => ' ',

    'Full first name in latin letters' => ' ',
    'Full last name in latin letters' => ' ',

    'First Name' => ' ',
    'Last Name' => ' ',
    'Country' => ' ',
    'Uploaded documents' => ' ',

    'Passport' => ' ',
    'Selfie' => ' ',
    'Drivers' => ' ',

    'approved' => ' ',
    'absent' => ' ',
    'wait' => ' ',
    'broken' => ' ',
    'declined' => ' ',

];