<?php
return [
    'Your session is about to expire' => '',
    'You will be logged out in'       => '',
    'sec'                             => '',
    'Do you want to stay signed in'   => '',
    'Yes, Keep me sign in'            => '',
    'No, Sign me out'                 => '',
    'Error'                           => '',
    'Current phase:'                  => ':',
    'Pre ICO'                         => '',
    'FAQ'                             => 'FAQ',
    'Terms of Conditions'             => '',
    'Funds collected'                 => '',
    'Contributors'                    => '',
    'Start'                           => '',
    'End'                             => '',
    'Sales phases'                    => '',
];
