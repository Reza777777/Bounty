<?php
return [
    'Show text passwords'                    => '',
    'Current Password'                       => '',
    'New password'                           => '',
    'Password confirmation'                  => '',
    'Change'                                 => '',
    'History of entrances'                   => '',
    'Showing the last login attempt'         => '',
    'Date'                                   => '',
    'IP address'                             => '',
    'Successfully'                           => '',
    'Yes'                                    => '',
    'No'                                     => '',
    'Please fix the following errors:'       => ':',
    'Password has been changed'              => '',
    'Your password was successfully changed' => '',
];
